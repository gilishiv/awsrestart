myvalue=25
print(type(myvalue))