import csv
import copy

with open('car_fleet.csv') as csvFile:
    csvReader = csv.reader(csvFile, delimiter=',')  
    lineCount = 0
    for row in csvReader:
        if lineCount==0:
            print("firstline")
            lineCount+=1
        elif lineCount==2:
            print("this is 3rd line")
        else:
            print("nextlines")