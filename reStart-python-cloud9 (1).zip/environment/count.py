import csv
import copy

with open('car_fleet.csv') as csvFile:
    csvReader = csv.reader(csvFile, delimiter=',')  
    lineCount = 0
    for i in csvReader:
        if i:
            lineCount+=1
            print(lineCount)
