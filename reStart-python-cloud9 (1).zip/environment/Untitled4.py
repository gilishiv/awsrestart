x=input('whats name')
print(x)