def getDoubleAlphabet(alphabet):
    doubleAlphabet = alphabet + alphabet
    return doubleAlphabet
    
alphabet="abc"
print(getDoubleAlphabet(alphabet))