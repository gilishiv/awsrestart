x=int(input("Enter the number: "))
if x>0:
    print("number is  positive")
elif x<0:
    print("number is negative")
else:
    print("this is zero")