ls=[4,5.3,"shiva"]



print(type(ls))






print(ls[0])
print(ls[-1])

ls[0]="amrit"
print(ls)