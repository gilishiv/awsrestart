x=int(input("Enter the number"))
if x>0:
    print("this is a positive number")
elif x<0:
    print("this is a negative number")
else:
    print("its a zero")