x=1
y=2
z=3


print(f'this is first way {x}, {y}, {z}')

print("this is second way {}, {}, {}".format(x,y,z))

print("this is third way {0}, {1}, {2}".format(x,y,z))

print("{0:.2f} {1:.3f} {2:.4f}".format(x,y,z))