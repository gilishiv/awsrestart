tup2=(4,5.3,"shiva")
print(type(tup2))
tup2[0]="amrit"
