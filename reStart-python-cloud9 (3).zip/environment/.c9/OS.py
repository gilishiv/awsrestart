import os
os.system("ls")